"use client"

import type React from "react"

import { Col, Card, Button } from "react-bootstrap"
import { motion } from "framer-motion"
import { FaTag, FaShoppingCart, FaStar, FaHeart, FaShare, FaClock, FaBox } from "react-icons/fa"
import styles from "./PromoPanel.module.css"

interface Promotion {
  id: number
  title: string
  description: string
  image_url: string
  cta_text: string
  cta_url: string
  is_active: boolean
  discount_percentage?: number | null
  start_date?: string | null
  end_date?: string | null
  price_range?: string
  tag?: string
  timer?: string
  stock?: string
}

interface PromoPanelProps {
  promotions: Promotion[]
}

const PromoPanel: React.FC<PromoPanelProps> = ({ promotions }) => {
  return (
    <>
      {/* Desktop Version - Keep Original */}
      <Col md={3} className={`${styles.promoPanel} d-none d-md-flex`}>
        <motion.div
          initial={{ opacity: 0, x: 50 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.8, ease: "easeOut" }}
        >
          <h3 className={styles.promoPanelTitle}>Offers & Deals</h3>
          {promotions.slice(0, 2).map((promo, index) => (
            <motion.div
              key={promo.id}
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: index * 0.3 }}
            >
              <Card className={styles.promoCard}>
                <Card.Img
                  variant="top"
                  src={promo.image_url}
                  alt={promo.title}
                  className={styles.promoImage}
                  onError={(e) => {
                    e.currentTarget.src = "https://placehold.co/400x200"
                  }}
                />
                <Card.Body>
                  <Card.Title className={styles.promoTitle}>
                    <FaTag className={styles.titleIcon} /> {promo.title}
                  </Card.Title>
                  {promo.discount_percentage && (
                    <Card.Text className={styles.promoDiscount}>{promo.discount_percentage}% Off</Card.Text>
                  )}
                  {promo.price_range && <Card.Text className={styles.promoPrice}>{promo.price_range}</Card.Text>}
                  {promo.tag && <Card.Text className={styles.promoTag}>{promo.tag}</Card.Text>}
                  <Card.Text className={styles.promoDescription}>{promo.description}</Card.Text>
                  {promo.timer && <Card.Text className={styles.promoTimer}>{promo.timer}</Card.Text>}
                  {promo.stock && <Card.Text className={styles.promoStock}>{promo.stock}</Card.Text>}
                  <Button href={promo.cta_url} className={styles.promoCta}>
                    <FaShoppingCart className={styles.ctaIcon} /> {promo.cta_text}
                  </Button>
                </Card.Body>
              </Card>
            </motion.div>
          ))}
        </motion.div>
      </Col>

      {/* Mobile Version - Revolutionary Design */}
      <motion.div
        initial={{ opacity: 0, y: 50 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.8, ease: "easeOut" }}
        className={`${styles.mobilePromoSection} d-md-none`}
      >
        {/* Floating Geometric Background */}
        <div className={styles.geometricBackground}>
          <motion.div
            className={styles.hexagon1}
            animate={{
              rotate: [0, 120, 240, 360],
              scale: [1, 1.1, 1],
            }}
            transition={{
              duration: 8,
              repeat: Number.POSITIVE_INFINITY,
              ease: "easeInOut",
            }}
          />
          <motion.div
            className={styles.triangle1}
            animate={{
              y: [0, -30, 0],
              rotate: [0, 180, 360],
            }}
            transition={{
              duration: 6,
              repeat: Number.POSITIVE_INFINITY,
              ease: "easeInOut",
            }}
          />
          <motion.div
            className={styles.diamond1}
            animate={{
              x: [0, 20, 0],
              rotate: [0, 45, 90],
            }}
            transition={{
              duration: 10,
              repeat: Number.POSITIVE_INFINITY,
              ease: "easeInOut",
            }}
          />
        </div>

        {/* Morphing Title */}
        <motion.div
          initial={{ opacity: 0, scale: 0.5 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 1, ease: "easeOut" }}
          className={styles.morphingTitleContainer}
        >
          <div className={styles.titleBubble}>
            <motion.h3
              className={styles.morphingTitle}
              animate={{
                backgroundPosition: ["0% 50%", "100% 50%", "0% 50%"],
              }}
              transition={{
                duration: 3,
                repeat: Number.POSITIVE_INFINITY,
                ease: "easeInOut",
              }}
            >
              ✨ Exclusive Deals
            </motion.h3>
            <div className={styles.titleTail} />
          </div>
        </motion.div>

        {/* Revolutionary Card Layout */}
        <div className={styles.revolutionaryContainer}>
          {promotions.slice(0, 2).map((promo, index) => (
            <motion.div
              key={promo.id}
              initial={{
                opacity: 0,
                x: index % 2 === 0 ? -200 : 200,
                rotate: index % 2 === 0 ? -45 : 45,
                scale: 0.3,
              }}
              animate={{
                opacity: 1,
                x: 0,
                rotate: 0,
                scale: 1,
              }}
              transition={{
                duration: 1.2,
                delay: index * 0.4 + 0.5,
                ease: "easeOut",
              }}
              whileHover={{
                scale: 1.02,
                rotate: index % 2 === 0 ? 2 : -2,
                transition: { duration: 0.3 },
              }}
              className={`${styles.revolutionaryCard} ${index % 2 === 0 ? styles.cardLeft : styles.cardRight}`}
            >
              {/* Organic Shape Container */}
              <div className={styles.organicShape}>
                {/* Floating Discount Hexagon */}
                {promo.discount_percentage && (
                  <motion.div
                    initial={{ scale: 0, rotate: -180 }}
                    animate={{ scale: 1, rotate: 0 }}
                    transition={{ duration: 0.8, delay: index * 0.4 + 1.2 }}
                    className={styles.hexagonDiscount}
                  >
                    <div className={styles.hexagonInner}>
                      <span className={styles.discountText}>{promo.discount_percentage}%</span>
                      <span className={styles.offText}>OFF</span>
                    </div>
                  </motion.div>
                )}

                {/* Circular Image Container */}
                <motion.div
                  initial={{ scale: 0, rotate: 180 }}
                  animate={{ scale: 1, rotate: 0 }}
                  transition={{ duration: 0.8, delay: index * 0.4 + 0.8 }}
                  className={styles.circularImageContainer}
                >
                  <div className={styles.imageRing}>
                    <motion.img
                      src={promo.image_url}
                      alt={promo.title}
                      className={styles.circularImage}
                      whileHover={{ scale: 1.1, rotate: 5 }}
                      transition={{ duration: 0.4 }}
                      onError={(e) => {
                        e.currentTarget.src = "https://placehold.co/400x200"
                      }}
                    />
                  </div>
                  <div className={styles.imageGlow} />
                </motion.div>

                {/* Floating Action Orbs */}
                <motion.div
                  initial={{ opacity: 0, scale: 0 }}
                  animate={{ opacity: 1, scale: 1 }}
                  transition={{ duration: 0.6, delay: index * 0.4 + 1.5 }}
                  className={styles.actionOrbs}
                >
                  <motion.div whileHover={{ scale: 1.3, rotate: 360 }} whileTap={{ scale: 0.9 }} className={styles.orb}>
                    <FaHeart />
                  </motion.div>
                  <motion.div
                    whileHover={{ scale: 1.3, rotate: -360 }}
                    whileTap={{ scale: 0.9 }}
                    className={styles.orb}
                  >
                    <FaShare />
                  </motion.div>
                </motion.div>

                {/* Asymmetric Content Area */}
                <div className={styles.asymmetricContent}>
                  {/* Curved Title Section */}
                  <motion.div
                    initial={{ opacity: 0, x: index % 2 === 0 ? -50 : 50 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ duration: 0.8, delay: index * 0.4 + 1.8 }}
                    className={styles.curvedTitleSection}
                  >
                    <div className={styles.titleCurve}>
                      <FaTag className={styles.floatingTag} />
                      <h4 className={styles.curvedTitle}>{promo.title}</h4>
                    </div>
                  </motion.div>

                  {/* Diagonal Info Strip */}
                  <motion.div
                    initial={{ opacity: 0, skewX: 45, x: 100 }}
                    animate={{ opacity: 1, skewX: 0, x: 0 }}
                    transition={{ duration: 0.8, delay: index * 0.4 + 2.1 }}
                    className={styles.diagonalStrip}
                  >
                    {promo.tag && (
                      <div className={styles.tagPill}>
                        <FaStar className={styles.starIcon} />
                        {promo.tag}
                      </div>
                    )}
                    {promo.price_range && <div className={styles.priceBubble}>{promo.price_range}</div>}
                  </motion.div>

                  {/* Flowing Description */}
                  <motion.div
                    initial={{ opacity: 0, y: 30 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.8, delay: index * 0.4 + 2.4 }}
                    className={styles.flowingDescription}
                  >
                    <p>{promo.description}</p>
                  </motion.div>

                  {/* Organic Meta Info */}
                  <motion.div
                    initial={{ opacity: 0, scale: 0.8 }}
                    animate={{ opacity: 1, scale: 1 }}
                    transition={{ duration: 0.8, delay: index * 0.4 + 2.7 }}
                    className={styles.organicMeta}
                  >
                    {promo.timer && (
                      <div className={styles.timerCapsule}>
                        <FaClock className={styles.metaIcon} />
                        <span>{promo.timer}</span>
                      </div>
                    )}
                    {promo.stock && (
                      <div className={styles.stockCapsule}>
                        <FaBox className={styles.metaIcon} />
                        <span>{promo.stock}</span>
                      </div>
                    )}
                  </motion.div>

                  {/* Morphing CTA Button */}
                  <motion.div
                    initial={{ opacity: 0, y: 50, scale: 0.5 }}
                    animate={{ opacity: 1, y: 0, scale: 1 }}
                    transition={{ duration: 0.8, delay: index * 0.4 + 3 }}
                    className={styles.morphingCtaContainer}
                  >
                    <motion.button
                      whileHover={{
                        scale: 1.05,
                        borderRadius: ["2rem", "3rem", "1rem", "2rem"],
                        transition: { duration: 0.6 },
                      }}
                      whileTap={{ scale: 0.95 }}
                      className={styles.morphingCta}
                    >
                      <motion.div
                        className={styles.ctaBackground}
                        animate={{
                          background: [
                            "linear-gradient(45deg, #9400d3, #ff1493)",
                            "linear-gradient(45deg, #ff1493, #a1dc17)",
                            "linear-gradient(45deg, #a1dc17, #9400d3)",
                            "linear-gradient(45deg, #9400d3, #ff1493)",
                          ],
                        }}
                        transition={{
                          duration: 4,
                          repeat: Number.POSITIVE_INFINITY,
                          ease: "easeInOut",
                        }}
                      />
                      <motion.span
                        animate={{ x: [0, 5, 0] }}
                        transition={{ duration: 2, repeat: Number.POSITIVE_INFINITY }}
                        className={styles.ctaIcon}
                      >
                        <FaShoppingCart />
                      </motion.span>
                      <span className={styles.ctaText}>{promo.cta_text}</span>
                      <div className={styles.ctaRipple} />
                    </motion.button>
                  </motion.div>
                </div>
              </div>
            </motion.div>
          ))}
        </div>

        {/* Floating Bottom Elements */}
        <motion.div
          initial={{ opacity: 0, y: 100 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 1, delay: 3.5 }}
          className={styles.floatingBottom}
        >
          <motion.div
            animate={{
              rotate: 360,
              scale: [1, 1.2, 1],
            }}
            transition={{
              rotate: { duration: 20, repeat: Number.POSITIVE_INFINITY, ease: "linear" },
              scale: { duration: 3, repeat: Number.POSITIVE_INFINITY, ease: "easeInOut" },
            }}
            className={styles.bottomOrb}
          >
            ✨
          </motion.div>
        </motion.div>
      </motion.div>
    </>
  )
}

export default PromoPanel
