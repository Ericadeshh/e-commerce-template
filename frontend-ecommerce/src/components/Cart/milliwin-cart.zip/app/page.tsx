"use client"

import PromoPanel from "../PromoPanel"
import MilliwinCart from "../cart-component"
import { Container, Row } from "react-bootstrap"
import "bootstrap/dist/css/bootstrap.min.css"

const mockPromotions = [
  {
    id: 1,
    title: "Summer Collection",
    description:
      "Trendy outfits for the season with premium quality fabrics and modern designs that will make you stand out",
    image_url: "/placeholder.svg?height=200&width=400",
    cta_text: "Shop Now",
    cta_url: "#",
    is_active: true,
    discount_percentage: 25,
    price_range: "$50 - $150",
    tag: "Limited Time",
    timer: "2 days left",
    stock: "Only 5 left",
  },
  {
    id: 2,
    title: "Designer Dresses",
    description: "Elegant dresses for special occasions crafted with attention to detail and sophisticated styling",
    image_url: "/placeholder.svg?height=200&width=400",
    cta_text: "View Collection",
    cta_url: "#",
    is_active: true,
    discount_percentage: 30,
    price_range: "$80 - $250",
    tag: "New Arrival",
    timer: "5 days left",
    stock: "In Stock",
  },
]

export default function Page() {
  return (
    <Container fluid className="py-4">
      <Row>
        <PromoPanel promotions={mockPromotions} />
        <MilliwinCart />
      </Row>
    </Container>
  )
}
