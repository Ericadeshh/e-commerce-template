"use client"

import { useState, useMemo } from "react"
import { Minus, Plus, X, Heart, ShoppingBag, Truck, Gift, Tag, ArrowRight, Shield, Clock } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Separator } from "@/components/ui/separator"
import { Badge } from "@/components/ui/badge"
import { Checkbox } from "@/components/ui/checkbox"

interface CartItem {
  id: string
  name: string
  price: number
  originalPrice?: number
  image: string
  quantity: number
  size?: string
  color?: string
  inStock: boolean
  category: string
}

interface ShippingOption {
  id: string
  name: string
  price: number
  estimatedDays: string
  description: string
}

export default function MilliwinCart() {
  const [cartItems, setCartItems] = useState<CartItem[]>([
    {
      id: "1",
      name: "Ankara Print Maxi Dress",
      price: 4500,
      originalPrice: 6000,
      image: "/placeholder.svg?height=120&width=120",
      quantity: 1,
      size: "M",
      color: "Blue & Gold",
      inStock: true,
      category: "Dresses",
    },
    {
      id: "2",
      name: "Kitenge Blazer",
      price: 3200,
      image: "/placeholder.svg?height=120&width=120",
      quantity: 2,
      size: "L",
      color: "Red & Black",
      inStock: true,
      category: "Blazers",
    },
    {
      id: "3",
      name: "Beaded Statement Necklace",
      price: 800,
      image: "/placeholder.svg?height=120&width=120",
      quantity: 1,
      color: "Gold",
      inStock: false,
      category: "Accessories",
    },
  ])

  const [savedItems, setSavedItems] = useState<string[]>([])
  const [promoCode, setPromoCode] = useState("")
  const [appliedPromo, setAppliedPromo] = useState<{ code: string; discount: number } | null>(null)
  const [selectedShipping, setSelectedShipping] = useState("standard")
  const [giftWrap, setGiftWrap] = useState(false)

  const shippingOptions: ShippingOption[] = [
    {
      id: "standard",
      name: "Standard Delivery",
      price: 200,
      estimatedDays: "3-5 business days",
      description: "Delivery within Nairobi and major towns",
    },
    {
      id: "express",
      name: "Express Delivery",
      price: 500,
      estimatedDays: "1-2 business days",
      description: "Fast delivery within Nairobi",
    },
    {
      id: "pickup",
      name: "Store Pickup",
      price: 0,
      estimatedDays: "Same day",
      description: "Collect from our Westlands store",
    },
  ]

  const promoCodes = {
    WELCOME10: 10,
    MILLIWIN20: 20,
    NEWCUSTOMER: 15,
  }

  const updateQuantity = (id: string, newQuantity: number) => {
    if (newQuantity === 0) {
      removeItem(id)
      return
    }
    setCartItems((items) =>
      items.map((item) => (item.id === id ? { ...item, quantity: Math.max(0, newQuantity) } : item)),
    )
  }

  const removeItem = (id: string) => {
    setCartItems((items) => items.filter((item) => item.id !== id))
  }

  const saveForLater = (id: string) => {
    setSavedItems((prev) => [...prev, id])
    removeItem(id)
  }

  const moveToCart = (id: string) => {
    setSavedItems((prev) => prev.filter((itemId) => itemId !== id))
    // In a real app, you'd restore the item to cart
  }

  const applyPromoCode = () => {
    const discount = promoCodes[promoCode as keyof typeof promoCodes]
    if (discount) {
      setAppliedPromo({ code: promoCode, discount })
      setPromoCode("")
    }
  }

  const removePromoCode = () => {
    setAppliedPromo(null)
  }

  const calculations = useMemo(() => {
    const subtotal = cartItems.reduce((sum, item) => sum + item.price * item.quantity, 0)
    const promoDiscount = appliedPromo ? (subtotal * appliedPromo.discount) / 100 : 0
    const selectedShippingOption = shippingOptions.find((option) => option.id === selectedShipping)
    const shippingCost = selectedShippingOption?.price || 0
    const giftWrapCost = giftWrap ? 150 : 0
    const taxRate = 0.16 // 16% VAT in Kenya
    const taxableAmount = subtotal - promoDiscount + shippingCost + giftWrapCost
    const tax = taxableAmount * taxRate
    const total = taxableAmount + tax

    return {
      subtotal,
      promoDiscount,
      shippingCost,
      giftWrapCost,
      tax,
      total,
    }
  }, [cartItems, appliedPromo, selectedShipping, giftWrap])

  if (cartItems.length === 0 && savedItems.length === 0) {
    return (
      <div className="max-w-4xl mx-auto p-6">
        <Card className="text-center py-12">
          <CardContent>
            <ShoppingBag className="mx-auto h-16 w-16 text-muted-foreground mb-4" />
            <h2 className="text-2xl font-semibold mb-2">Your cart is empty</h2>
            <p className="text-muted-foreground mb-6">Discover our beautiful collection of African-inspired fashion</p>
            <Button size="lg" className="bg-orange-600 hover:bg-orange-700">
              Continue Shopping
            </Button>
          </CardContent>
        </Card>
      </div>
    )
  }

  return (
    <div className="max-w-7xl mx-auto p-4 lg:p-6">
      {/* Header */}
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900 mb-2">Shopping Cart</h1>
        <p className="text-muted-foreground">
          {cartItems.length} {cartItems.length === 1 ? "item" : "items"} in your cart
        </p>
      </div>

      <div className="grid lg:grid-cols-3 gap-8">
        {/* Cart Items */}
        <div className="lg:col-span-2 space-y-6">
          {/* Active Cart Items */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <ShoppingBag className="h-5 w-5" />
                Cart Items
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {cartItems.map((item) => (
                <div key={item.id} className="flex gap-4 p-4 border rounded-lg">
                  <div className="relative">
                    <img
                      src={item.image || "/placeholder.svg"}
                      alt={item.name}
                      className="w-24 h-24 object-cover rounded-md"
                    />
                    {item.originalPrice && <Badge className="absolute -top-2 -right-2 bg-red-500">Sale</Badge>}
                  </div>

                  <div className="flex-1 space-y-2">
                    <div className="flex justify-between items-start">
                      <div>
                        <h3 className="font-semibold text-lg">{item.name}</h3>
                        <p className="text-sm text-muted-foreground">{item.category}</p>
                        {item.size && (
                          <p className="text-sm">
                            Size: <span className="font-medium">{item.size}</span>
                          </p>
                        )}
                        {item.color && (
                          <p className="text-sm">
                            Color: <span className="font-medium">{item.color}</span>
                          </p>
                        )}
                      </div>
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => removeItem(item.id)}
                        className="text-muted-foreground hover:text-red-500"
                      >
                        <X className="h-4 w-4" />
                      </Button>
                    </div>

                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <span className="font-semibold text-lg">KSh {item.price.toLocaleString()}</span>
                        {item.originalPrice && (
                          <span className="text-sm text-muted-foreground line-through">
                            KSh {item.originalPrice.toLocaleString()}
                          </span>
                        )}
                      </div>

                      <div className="flex items-center gap-3">
                        <div className="flex items-center border rounded-md">
                          <Button
                            variant="ghost"
                            size="icon"
                            className="h-8 w-8"
                            onClick={() => updateQuantity(item.id, item.quantity - 1)}
                          >
                            <Minus className="h-3 w-3" />
                          </Button>
                          <span className="px-3 py-1 min-w-[3rem] text-center">{item.quantity}</span>
                          <Button
                            variant="ghost"
                            size="icon"
                            className="h-8 w-8"
                            onClick={() => updateQuantity(item.id, item.quantity + 1)}
                          >
                            <Plus className="h-3 w-3" />
                          </Button>
                        </div>

                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => saveForLater(item.id)}
                          className="flex items-center gap-1"
                        >
                          <Heart className="h-3 w-3" />
                          Save
                        </Button>
                      </div>
                    </div>

                    {!item.inStock && (
                      <div className="flex items-center gap-2 text-red-600 text-sm">
                        <Clock className="h-4 w-4" />
                        Out of stock - will ship when available
                      </div>
                    )}
                  </div>
                </div>
              ))}
            </CardContent>
          </Card>

          {/* Saved Items */}
          {savedItems.length > 0 && (
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Heart className="h-5 w-5" />
                  Saved for Later ({savedItems.length})
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground">Items you've saved will appear here</p>
              </CardContent>
            </Card>
          )}

          {/* Promo Code */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Tag className="h-5 w-5" />
                Promo Code
              </CardTitle>
            </CardHeader>
            <CardContent>
              {appliedPromo ? (
                <div className="flex items-center justify-between p-3 bg-green-50 border border-green-200 rounded-md">
                  <div className="flex items-center gap-2">
                    <Badge variant="secondary" className="bg-green-100 text-green-800">
                      {appliedPromo.code}
                    </Badge>
                    <span className="text-sm text-green-700">{appliedPromo.discount}% discount applied</span>
                  </div>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={removePromoCode}
                    className="text-green-700 hover:text-green-800"
                  >
                    Remove
                  </Button>
                </div>
              ) : (
                <div className="flex gap-2">
                  <Input
                    placeholder="Enter promo code"
                    value={promoCode}
                    onChange={(e) => setPromoCode(e.target.value.toUpperCase())}
                    className="flex-1"
                  />
                  <Button onClick={applyPromoCode} variant="outline">
                    Apply
                  </Button>
                </div>
              )}
              <div className="mt-3 text-xs text-muted-foreground">Try: WELCOME10, MILLIWIN20, or NEWCUSTOMER</div>
            </CardContent>
          </Card>
        </div>

        {/* Order Summary */}
        <div className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Order Summary</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <div className="flex justify-between">
                  <span>Subtotal</span>
                  <span>KSh {calculations.subtotal.toLocaleString()}</span>
                </div>

                {calculations.promoDiscount > 0 && (
                  <div className="flex justify-between text-green-600">
                    <span>Promo Discount</span>
                    <span>-KSh {calculations.promoDiscount.toLocaleString()}</span>
                  </div>
                )}

                <div className="flex justify-between">
                  <span>Shipping</span>
                  <span>
                    {calculations.shippingCost === 0 ? "Free" : `KSh ${calculations.shippingCost.toLocaleString()}`}
                  </span>
                </div>

                {giftWrap && (
                  <div className="flex justify-between">
                    <span>Gift Wrap</span>
                    <span>KSh {calculations.giftWrapCost.toLocaleString()}</span>
                  </div>
                )}

                <div className="flex justify-between">
                  <span>VAT (16%)</span>
                  <span>KSh {calculations.tax.toLocaleString()}</span>
                </div>
              </div>

              <Separator />

              <div className="flex justify-between font-semibold text-lg">
                <span>Total</span>
                <span>KSh {calculations.total.toLocaleString()}</span>
              </div>

              <Button className="w-full bg-orange-600 hover:bg-orange-700 text-white" size="lg">
                Proceed to Checkout
                <ArrowRight className="ml-2 h-4 w-4" />
              </Button>

              <div className="flex items-center justify-center gap-2 text-sm text-muted-foreground">
                <Shield className="h-4 w-4" />
                Secure checkout with SSL encryption
              </div>
            </CardContent>
          </Card>

          {/* Shipping Options */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Truck className="h-5 w-5" />
                Shipping Options
              </CardTitle>
            </CardHeader>
            <CardContent>
              <RadioGroup value={selectedShipping} onValueChange={setSelectedShipping}>
                {shippingOptions.map((option) => (
                  <div key={option.id} className="flex items-start space-x-3 p-3 border rounded-md">
                    <RadioGroupItem value={option.id} id={option.id} className="mt-1" />
                    <div className="flex-1">
                      <Label htmlFor={option.id} className="font-medium cursor-pointer">
                        {option.name}
                      </Label>
                      <p className="text-sm text-muted-foreground">{option.description}</p>
                      <p className="text-sm font-medium">{option.estimatedDays}</p>
                    </div>
                    <span className="font-medium">{option.price === 0 ? "Free" : `KSh ${option.price}`}</span>
                  </div>
                ))}
              </RadioGroup>
            </CardContent>
          </Card>

          {/* Additional Options */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Gift className="h-5 w-5" />
                Additional Options
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-center space-x-2">
                <Checkbox id="gift-wrap" checked={giftWrap} onCheckedChange={setGiftWrap} />
                <Label htmlFor="gift-wrap" className="text-sm cursor-pointer">
                  Add gift wrapping (+KSh 150)
                </Label>
              </div>
            </CardContent>
          </Card>

          {/* Trust Badges */}
          <Card>
            <CardContent className="pt-6">
              <div className="text-center space-y-3">
                <h4 className="font-medium">Why shop with Milliwin Boutique?</h4>
                <div className="space-y-2 text-sm text-muted-foreground">
                  <div className="flex items-center gap-2">
                    <Shield className="h-4 w-4 text-green-600" />
                    <span>Authentic African designs</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Truck className="h-4 w-4 text-blue-600" />
                    <span>Free delivery on orders over KSh 5,000</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Heart className="h-4 w-4 text-red-600" />
                    <span>30-day return policy</span>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}
